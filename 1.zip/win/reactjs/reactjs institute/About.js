import React from 'react'

function About() {
    return (
        <div>
         K.E. Society's <br/>

Rajarambapu Institute Of Technology Rajaramnagar, Islampur, Tal. Walwa, Dist. Sangli,<br/>

Maharashtra, India - 415414.<br/>

E-Mail : director@ritindia.edu<br/>
Tel : - +91 - 2342 – 220329, 9970700700, <br/>For MBA : 226488, , 9970700810<br/>

Fax : - +91 - 2342 – 220989
        </div>
    )
}

export default About
