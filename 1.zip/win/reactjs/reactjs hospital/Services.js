import React from 'react'

function Services() {
    return (
        <div>
             <h1 className='mb-3'>DYP hospital kolhapur</h1>
             <h4>patient Treated : 400000</h4>
             <h4>covid patient Treated : 10000</h4>

             <h4>Number of recovered from covid : 9998   </h4>
             <br/>
<hr/>
             <h2 className='mb-3'>Admission</h2>
             <h4>address : kolhapur</h4>
             <h4>pin code: 416118</h4>
             
             <h4>parking facility availables</h4>
             
        </div>
    )
}

export default Services
