import React from 'react'

function About() {
    return (
        <div>
        DYP Hospital, Islampur, Tal. Walwa, Dist. Sangli,<br/>

Maharashtra, India - 416118.<br/>

E-Mail : director@DYP.com<br/>
Tel : - +91 - 2342 – 220329, 9970700700, <br/>For MBA : 226488, , 9970700810<br/>

Fax : - +91 - 2342 – 220989
        </div>
    )
}

export default About
