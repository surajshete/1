import React from 'react'
import logo from "./logo.jpg"

function Home() {
        

    return (
        <div>


            <h1 className='mb-3'>DYP hospital kolhapur </h1><br/>
           <hr/> 
            <img className='logo' src={logo} alt="LOGO"  width="1600" height="400"  ></img>
            <hr/> 
            <h1>---Facilities---</h1>
            
            <h4 className='mb-3'> Operation Theaters </h4>
            <label>Emergency Control</label>
            <h4> Test Labs</h4>
            <label>Labs for tests</label>

             <h4>x ray facilities</h4>
             <label>x ray machine available</label>

            <h4>ventiltors</h4>
            <label>ventiltors are availables</label>
            

            <h4>Blood banks</h4>
            <label>blood bank is availables</label>
            <h4> charity program</h4>
            <label>you can donate money here.</label>
            </div>
    )
}

export default Home